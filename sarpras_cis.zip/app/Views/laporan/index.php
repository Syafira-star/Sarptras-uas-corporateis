<?= $this->extend('layout/main'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
  <h2>Laporan Penggunaan Fasilitas</h2>

  <!-- Filter Tanggal -->
  <form method="get" class="form-inline mb-3">
    <label for="tanggal_mulai" class="mr-2">Dari:</label>
    <input type="date" name="tanggal_mulai" id="tanggal_mulai" class="form-control mr-3" value="<?= esc($_GET['tanggal_mulai'] ?? '') ?>">

    <label for="tanggal_akhir" class="mr-2">Sampai:</label>
    <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control mr-3" value="<?= esc($_GET['tanggal_akhir'] ?? '') ?>">
    <label for="urut" class="mr-2">Urutkan:</label>
    <select name="urut" id="urut" class="form-control mr-3">
        <option value="asc" <?= (isset($_GET['urut']) && $_GET['urut'] === 'asc') ? 'selected' : '' ?>>Terlama</option>
        <option value="desc" <?= (isset($_GET['urut']) && $_GET['urut'] === 'desc') ? 'selected' : '' ?>>Terbaru</option>
    </select>
    <button type="submit" class="btn btn-primary mr-2">Tampilkan</button>

    <?php if (!empty($_GET['tanggal_mulai']) && !empty($_GET['tanggal_akhir'])) : ?>
      <a href="<?= base_url('laporan/cetak?tanggal_mulai=' . $_GET['tanggal_mulai'] . '&tanggal_akhir=' . $_GET['tanggal_akhir']) ?>" target="_blank" class="btn btn-success">Cetak</a>
    <?php endif; ?>
  </form>

  <!-- Tabel Laporan -->
  <div class="table-responsive">
    <table class="table table-bordered table-striped">
      <thead class="thead-light">
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>Instansi</th>
          <th>Tanggal</th>
          <th>Waktu</th>
          <th>Prasarana</th>
          <th>Sarana</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($peminjaman)) : ?>
          <tr>
            <td colspan="7" class="text-center text-muted">Tidak ada data peminjaman.</td>
          </tr>
        <?php else : ?>
          <?php $no = 1; foreach ($peminjaman as $p) : ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= esc($p['nama_penanggung_jawab']) ?></td>
              <td><?= esc($p['instansi']) ?></td>
              <td><?= esc($p['tanggal_peminjaman']) ?></td>
              <td><?= esc($p['waktu_mulai']) ?> - <?= esc($p['waktu_selesai']) ?></td>
              <td><?= esc($p['prasarana'] ?? '-') ?></td>
              <td>
  <?php if (!empty($p['detail_sarana'])) : ?>
    <?php foreach ($p['detail_sarana'] as $ds) : ?>
      <?= esc($ds['nama']) ?> (<?= esc($ds['jumlah']) ?>)<br>
    <?php endforeach; ?>
  <?php else : ?>
    -
  <?php endif; ?>
</td>

            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection(); ?>
