<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Halaman Laporan</h2>
<p>Ini adalah halaman laporan. Nantinya akan menampilkan rekap data seperti laporan peminjaman, penggunaan sarana, dll.</p>
<?= $this->endSection() ?>
