<nav class="navbar navbar-header navbar-expand-lg" data-background-color="blue2">
  <div class="container-fluid">
    <div class="navbar-nav ml-auto">
      <li class="nav-item dropdown">
        <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#">
          <i class="fas fa-user-circle text-white"></i>
          <span class="text-white"><?= session()->get('username') ?></span>
        </a>
        <ul class="dropdown-menu dropdown-user animated fadeIn">
          <li><a class="dropdown-item" href="<?= base_url('akun') ?>">Akun Saya</a></li>
        </ul>
      </li>
    </div>
  </div>
</nav>
