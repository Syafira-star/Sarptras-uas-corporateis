<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Halaman History Sistem</h2>
<p>Halaman ini menampilkan riwayat aktivitas sistem, seperti log peminjaman, update data, dan perubahan lainnya.</p>
<?= $this->endSection() ?>
