<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Halaman Data Peminjaman</h2>
<p>Ini adalah halaman untuk menampilkan daftar dan status peminjaman fasilitas kampus.</p>
<?= $this->endSection() ?>
