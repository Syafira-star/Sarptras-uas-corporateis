<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Halaman Pengaturan</h2>
<p>Halaman ini untuk pengelolaan akun, visi misi, struktur organisasi, dan konfigurasi sistem lainnya.</p>
<?= $this->endSection() ?>
