<?= $this->extend('layout/main'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
  <h2>Dashboard</h2>
  
  <div class="row">
    <!-- Jumlah Gedung -->
    <div class="col-md-3">
      <div class="card text-white bg-primary mb-3">
        <div class="card-body">
          <h5 class="card-title">Jumlah Gedung</h5>
          <p class="card-text display-4"><?= $jumlahGedung ?></p>
        </div>
      </div>
    </div>

    <!-- Jumlah Ruang -->
    <div class="col-md-3">
      <div class="card text-white bg-success mb-3">
        <div class="card-body">
          <h5 class="card-title">Jumlah Ruang</h5>
          <p class="card-text display-4"><?= $jumlahRuang ?></p>
        </div>
      </div>
    </div>

    <!-- Jumlah Sarana -->
    <div class="col-md-3">
      <div class="card text-white bg-warning mb-3">
        <div class="card-body">
          <h5 class="card-title">Jumlah Sarana</h5>
          <p class="card-text display-4"><?= $jumlahSarana ?></p>
        </div>
      </div>
    </div>

    <!-- Jumlah Peminjaman -->
    <div class="col-md-3">
      <div class="card text-white bg-danger mb-3">
        <div class="card-body">
          <h5 class="card-title">Jumlah Peminjaman</h5>
          <p class="card-text display-4"><?= $jumlahPeminjaman ?></p>
        </div>
      </div>
    </div>
  </div>

  <div class="card mt-4">
  <div class="card-header">
    <h4 class="card-title">Ruang Paling Sering Dipinjam</h4>
  </div>
  <div class="card-body">
    <canvas id="grafikRuang" height="100"></canvas>
  </div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  fetch('<?= base_url('dashboard/grafik') ?>')
    .then(response => response.json())
    .then(data => {
      const ctx = document.getElementById('grafikRuang').getContext('2d');
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: data.labels,
          datasets: [{
            label: 'Jumlah Peminjaman',
            data: data.jumlah,
            backgroundColor: '#007bff'
          }]
        },
        options: {
          animation: {
            duration: 800, // cukup 1 kali animasi
            easing: 'easeOutQuart'
          },
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                precision: 0
              }
            }
          }
        }
      });
    });
</script>
</div>

<?= $this->endSection(); ?>
