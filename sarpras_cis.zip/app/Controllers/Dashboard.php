<?php

namespace App\Controllers;

use App\Models\GedungModel;
use App\Models\RuangModel;
use App\Models\SaranaModel;
use App\Models\PeminjamanModel;

class Dashboard extends BaseController
{
   public function index()
{
    $gedungModel = new \App\Models\GedungModel();
    $ruangModel  = new \App\Models\RuangModel();
    $saranaModel = new \App\Models\SaranaModel();
    $peminjamanModel = new \App\Models\PeminjamanModel();

    // Ambil total jumlah data
    $data['jumlahGedung'] = $gedungModel->countAll();
    $data['jumlahRuang']  = $ruangModel->countAll();
    $data['jumlahSarana'] = $saranaModel->countAll();
    $data['jumlahPeminjaman'] = $peminjamanModel->where('status', 'Diterima')->countAllResults();

    // Ambil data grafik: jumlah peminjaman per ruang
    $db = \Config\Database::connect();
    $builder = $db->table('tb_peminjaman_sarana');
    $builder->select('tb_ruang.nama_ruang, COUNT(tb_peminjaman_sarana.id) as jumlah');
    $builder->join('tb_sarana', 'tb_sarana.id = tb_peminjaman_sarana.sarana_id');
    $builder->join('tb_ruang', 'tb_ruang.id = tb_sarana.ruang_id');
    $builder->join('tb_peminjaman', 'tb_peminjaman.id = tb_peminjaman_sarana.peminjaman_id');
    $builder->where('tb_peminjaman.status', 'Diterima');
    $builder->groupBy('tb_ruang.nama_ruang');
    $builder->orderBy('jumlah', 'DESC');
    $builder->limit(6);

    $grafik = $builder->get()->getResultArray();

    $data['labels'] = array_column($grafik, 'nama_ruang');
    $data['jumlah'] = array_column($grafik, 'jumlah');

    return view('dashboard/index', $data);
}


public function getGrafik()
{
    $db = \Config\Database::connect();

    $builder = $db->table('tb_peminjaman_sarana');
    $builder->select('tb_ruang.nama_ruang, COUNT(tb_peminjaman_sarana.id) as jumlah');
    $builder->join('tb_sarana', 'tb_sarana.id = tb_peminjaman_sarana.sarana_id');
    $builder->join('tb_ruang', 'tb_ruang.id = tb_sarana.ruang_id');
    $builder->join('tb_peminjaman', 'tb_peminjaman.id = tb_peminjaman_sarana.peminjaman_id');
    $builder->where('tb_peminjaman.status', 'Diterima');
    $builder->groupBy('tb_ruang.nama_ruang');
    $builder->orderBy('jumlah', 'DESC');
    $builder->limit(6);

    $query = $builder->get()->getResultArray();

    $labels = [];
    $jumlah = [];

    foreach ($query as $row) {
        $labels[] = $row['nama_ruang'];
        $jumlah[] = (int) $row['jumlah'];
    }

    return $this->response->setJSON([
        'labels' => $labels,
        'jumlah' => $jumlah
    ]);
}


}
