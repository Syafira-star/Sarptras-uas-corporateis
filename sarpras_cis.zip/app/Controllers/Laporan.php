<?php

namespace App\Controllers;

use App\Models\PeminjamanModel;
use App\Models\PeminjamanSaranaModel;

class Laporan extends BaseController
{
    public function index()
    {
        $model = new PeminjamanModel();

        $tanggalMulai = $this->request->getGet('tanggal_mulai');
        $tanggalAkhir = $this->request->getGet('tanggal_akhir');
        $urut = $this->request->getGet('urut') ?? 'asc';

        $query = $model->where('status', 'Diterima');

        if ($tanggalMulai && $tanggalAkhir) {
            $query = $query->where('tanggal_peminjaman >=', $tanggalMulai)
                           ->where('tanggal_peminjaman <=', $tanggalAkhir);
        }
        
        $query->orderBy('tanggal_peminjaman', $urut);

        $peminjaman = $query->findAll();

    // Ambil data peminjaman_sarana
    $peminjamanSaranaModel = new PeminjamanSaranaModel();
    foreach ($peminjaman as &$item) {
        $sarana = $peminjamanSaranaModel
                    ->select('tb_sarana.nama, tb_peminjaman_sarana.jumlah')
                    ->join('tb_sarana', 'tb_sarana.id = tb_peminjaman_sarana.sarana_id')
                    ->where('tb_peminjaman_sarana.peminjaman_id', $item['id'])
                    ->findAll();

        $item['detail_sarana'] = $sarana;
    }

    $data = [
        'peminjaman'     => $peminjaman,
        'tanggal_mulai'  => $tanggalMulai,
        'tanggal_akhir'  => $tanggalAkhir,
        'title'          => 'Laporan Penggunaan Fasilitas',
    ];

        return view('laporan/index', $data);
    }

    public function cetak()
{
    $model = new \App\Models\PeminjamanModel();
    $peminjamanSaranaModel = new \App\Models\PeminjamanSaranaModel();
    $saranaModel = new \App\Models\SaranaModel();

    $tanggal_mulai = $this->request->getGet('tanggal_mulai');
    $tanggal_akhir = $this->request->getGet('tanggal_akhir');

    $query = $model->where('status', 'Diterima');

    if ($tanggal_mulai && $tanggal_akhir) {
        $query->where('tanggal_peminjaman >=', $tanggal_mulai)
              ->where('tanggal_peminjaman <=', $tanggal_akhir);
    }

    $peminjaman = $query->findAll();

    // Tambahkan data sarana ke masing-masing peminjaman
    foreach ($peminjaman as &$p) {
        $dataSarana = $peminjamanSaranaModel
            ->where('peminjaman_id', $p['id'])
            ->findAll();

        // Ambil nama sarana dari tb_sarana
        $listSarana = [];
        foreach ($dataSarana as $ds) {
            $namaSarana = $saranaModel->find($ds['sarana_id'])['nama'] ?? 'Tidak diketahui';
            $listSarana[] = [
                'nama_sarana' => $namaSarana,
                'jumlah'      => $ds['jumlah']
            ];
        }

        $p['sarana'] = $listSarana; // masukkan array ke dalam peminjaman
    }

    $data = [
        'peminjaman'     => $peminjaman,
        'tanggal_mulai'  => $tanggal_mulai,
        'tanggal_akhir'  => $tanggal_akhir,
        'title'          => 'Cetak Laporan'
    ];

    return view('laporan/cetak', $data);
}

}
