<?php

namespace App\Controllers;

class Pengaturan extends BaseController
{
    public function index()
    {
        return view('pengaturan', ['title' => 'Pengaturan']);
    }
}
